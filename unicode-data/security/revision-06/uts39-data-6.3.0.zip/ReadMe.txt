This directory contains the data files for version 6.3.0 of UTS #39: Unicode Security Mechanisms.

For more information, see http://www.unicode.org/reports/tr39/.