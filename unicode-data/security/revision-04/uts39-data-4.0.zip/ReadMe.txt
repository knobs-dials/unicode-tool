This directory contains the draft data files for Revision 4 of UTS #39: Unicode Security Mechanisms.

For more information, see http://www.unicode.org/reports/tr39/tr39-4.html.
