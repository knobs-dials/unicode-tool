# Unicode Security Data (Confusables and Identifiers)
# © 2019 Unicode®, Inc.
# Unicode and the Unicode Logo are registered trademarks of Unicode, Inc. in the U.S. and other countries.
# For terms of use, see http://www.unicode.org/terms_of_use.html

This directory contains the final data files for Version 12.0.0 of
UTS #39: Unicode Security Mechanisms (http://www.unicode.org/reports/tr39/)
