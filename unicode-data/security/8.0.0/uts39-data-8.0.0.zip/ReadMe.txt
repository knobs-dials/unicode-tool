This directory contains the draft data files for version 8.0.0 
of UTS #39: Unicode Security Mechanisms.

For more information, see http://www.unicode.org/reports/tr39/tr39-10.html.
